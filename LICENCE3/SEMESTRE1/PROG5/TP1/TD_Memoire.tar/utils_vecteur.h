#ifndef __UTILS__
#define __UTILS__

vecteur construit_vecteur(int n, double *donnees);
void affiche_vecteur(vecteur v);
vecteur lit_vecteur(char *fichier);

#endif
