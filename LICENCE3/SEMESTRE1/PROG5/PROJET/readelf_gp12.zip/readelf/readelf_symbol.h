#ifndef ETAPE_4
#define ETAPE_4

int read_symbole(int fd, elf *donnees);

int print_symbole(int fd, elf *donnees);

#endif
