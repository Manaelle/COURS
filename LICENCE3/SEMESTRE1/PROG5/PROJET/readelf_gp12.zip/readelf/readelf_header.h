#ifndef ETAPE_1
#define ETAPE_1


int read_header(int fd, elf *donnees);

int print_header(elf *donnees);

#endif
