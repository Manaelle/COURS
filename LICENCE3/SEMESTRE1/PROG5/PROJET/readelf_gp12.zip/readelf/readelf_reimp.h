#ifndef ETAPE_5
#define ETAPE_5


int print_reimp(int fd, elf *donnees);

#endif

