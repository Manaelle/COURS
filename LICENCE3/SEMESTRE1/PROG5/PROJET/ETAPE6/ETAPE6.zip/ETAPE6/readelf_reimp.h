#ifndef ETAPE_5
#define ETAPE_5


int print_reimp(int fd, Elf32_Ehdr *ehdr, Elf32_Shdr *shdrTable, char *tabNames, Elf32_Rel *rel, int *error);

#endif

