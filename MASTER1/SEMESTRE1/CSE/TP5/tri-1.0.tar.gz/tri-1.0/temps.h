#ifndef __TEMPS__
#define __TEMPS__

long long int to_usec(struct timeval t);

#endif
