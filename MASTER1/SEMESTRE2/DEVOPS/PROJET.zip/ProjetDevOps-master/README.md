
[![Build Status](https://travis-ci.org/hirouka/ProjetDevOps.svg?branch=master)](https://travis-ci.org/hirouka/travis-badge)
[![Coverage](https://codecov.io/gh/hirouka/ProjetDevOps/branch/master/graph/badge.svg)](https://codecov.io/gh/hirouka/ProjetDevOps)


## Répartition des tâches
### Marianne : 
- Constructeur depuis des données [FAIT]
- Select sur Dataframe [FAIT]
- Manipulations sur le DataFrame
### Nadia :
- Constructeur depuis un fichier [FAIT]
- Info sur le Dataframe [EN COURS]
- Opérations statistiques

### Manal :
- TEST. TEST ET TEST.
- Secrétariat.

## Implémentation
### Constructeurs

- Création d'un dataframe vide (sans ligne et sans colonne)
> DataFrame D = new DataFrame();

- Création d'un dataframe à partir d'un fichier .csv
> DataFrame D = new DataFrame("/toto/nomfichier.csv");

- Création d'un dataframe dont on donne directement les données
>	ArrayList<String> Label = new ArrayList<String>("Label1", "Label2", "Label3");
> 
> ArrayList<Object> Line1 = new ArrayList<String>(22, 42.99, "blabla");
> ArrayList<Object> Line2 = new ArrayList<String>(23, 2.55, "blablablaaaa");
> ArrayList<ArrayList> Data = new ArrayList<ArrayList>(Line1, Line2);
> 
> DataFrame D = new DataFrame(Label, Data);

### Méthodes
#### Info sur le Dataframe

- Afficher le dataframe en console.
> D.print();

- renvoie un dataframe avec les 2 premières lignes (resp. les deux dernières pour tail).
> D.head(2);
> D.tail(2);

-  Donne une liste des noms des colonnes (label)
> D.getLabel();

#### Select from Dataframe
##### Par rapport aux lignes
- Retourne un Dataframe contenant la ligne x
> Dataframe E = D.getRow(int x);

- Retourne un Dataframe contenant LES lignes x1, x2...xn (Dans l'exemple, on aura la ligne 1,2,5 et 8)
> int[] lines ={1,2,5,8};
> Dataframe E = D.getRows(lines);
  
  - Retourne un Dataframe contenant LES lignes de x1 à xn (Dans l'exemple, on aura toutes les lignes de 1 à 8)
> Dataframe E = D.getRowsBetween(1, 8);

Nota Bene : Dans getRowsBetween(), x1 et xn sont INCLUS.

##### Par rapport aux colonnes
- Retourne un Dataframe contenant la colonne "Label1"
> Dataframe E = D.getColumn("Label1");

- Retourne un Dataframe contenant LES colonnes a1, a2...an (Dans l'exemple, on aura les colonnes "toto", "titi", "tutu")
> ArrayList<String> Labels = new ArrayList<String>("toto", "titi", "tutu");
> Dataframe E = D.getColumns(Labels);
  
  
##### Sélections avancées
- Retourne l'élément se trouvant à la ligne x, label L
> Object E = D.getElement(int x, String L);

Nota Bene : Ca revient à faire un getColumn() puis un getRow()

#### Opérations Statistiques sur Dataframe
- Retourne la moyenne de toutes les valeurs de la colonne donnée :
> Number med = D.median("Label1");

- Retourne la somme de toutes les valeurs de la colonne donnée :
> Number sum = D.sum("Label1");

- Retourne le minimum de toutes les valeurs de la colonne donnée :
> Number min = D.min("Label1");

- Retourne le maximum de toutes les valeurs de la colonne donnée :
> Number max = D.max("Label1");

Nota Bene : S'applique (évidemment...) que si les éléments de la colonne donnée sont des Numbers/Float/Int etc... Si certains éléments sont NULL, ils sont simplement ommis.

#### Autres opérations
##### Manipulation sur Dataframe
- Ajouter des lignes au Dataframe D à partir d'une liste de lignes
> ArrayList<Object> Line1 = new ArrayList<String>(22, 42.99, "blabla");
> ArrayList<Object> Line2 = new ArrayList<String>(23, 2.55, "blablablaaaa");
> ArrayList<ArrayList> Data = new ArrayList<ArrayList>(Line1, Line2);
> D.addRows(Data);
  
  Nota Bene : Si une ligne n'est pas correcte, elle est ommise et les autres lignes (correctes) sont ajoutées. Lors de l'ajout d'une ligne, le nombre de colonne et le typage est vérifié.
  
  - Ajouter des colonnes au Dataframe D à partir d'une liste de labels (dans l'exemple, "tonton" et "tati" sont ajoutés). Les colonnes ajoutés contiennent "NULL" sur toute les lignes correspondantes
  > ArrayList<String> Labels = new ArrayList<String>("tonton", "tati");
  > D.addColumns(Labels);
  
  - Change l'élément e trouvant à la ligne x, label L par la valeur C
 > D.setElement(Object C, int x, String L);
 
 - Retourne l'union (sur les lignes !) de deux DataFrames D1 et D2. D1 et D2 DOIVENT avoir les MEMES labels !
 > DataFrame D3 = D1.union(D2);
 
 - Retourne l'intersection (sur les lignes !) de deux DataFrames D1 et D2. D1 et D2 DOIVENT avoir les MEMES labels !
 > D1.intersection(D2);
 
 - Retourne TRUE si D1 et D2 sont égaux, FALSE sinon.
 > D1.equal(D2);
 
 - FACULTATIF : Retourne la jointure de D1 et D2 (Voir les jointures SQL)
 > ArrayList<String> Labels = new ArrayList<String>("tonton","tata");
 > DataFrame D3 = D3.join(D1, D2, Labels);

Nota Bene : Choisir/Spécifier la jointure qu'on veut faire : innerJoin(), crossJoin() etc...
