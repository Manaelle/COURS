/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataframe;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.apache.commons.io.FileUtils;


/**
 * Classe de gestion de tests de dataframes.
 * @version 1.0
 * @author Manal
 */
public class DataFrameTest {

    public static ArrayList<File> listTestFile;

    @ClassRule
    public static TemporaryFolder testFolder = new TemporaryFolder();

    @Rule
    public ExpectedException ex = ExpectedException.none();

    //----------------------------------------------------------------
    @BeforeClass
    public static void setUpClass() throws IOException {
        listTestFile = new ArrayList<File>();

        //F1 : Fichier CSV classique et correct, sans répétition, avec 5 entrées
        final File F1 = testFolder.newFile("testGoodFile5entries.csv");
        FileUtils.writeStringToFile(F1, "Firstname,Lastname,Age\nJill,Smith,50\nEve,Jackson,94\nMaurice,Dupont,40\nLoris,Morez,20\nEdith,Euriez,34", Charset.defaultCharset());
        listTestFile.add(F1);

        //F2 : Fichier CSV classique et correct, vide
        final File F2 = testFolder.newFile("testFileEmpty.csv");
        listTestFile.add(F2);

    }
    //----------------------------------------------------------------
    @AfterClass
    public static void tearDownClass() {
    }
    //----------------------------------------------------------------
    @Before
    public void setUp() {
    }
    //----------------------------------------------------------------
    @After
    public void tearDown() {
    }

    //----------------------------------------------------
    //--------------------CONSTRUCTORS--------------------
    //----------------------------------------------------
    @Test
    public void creationTest_isWellCreatedfromGoodFile() throws Exception{
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        //final String s = FileUtils.readFileToString(tempFile, Charset.defaultCharset());

        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Jill,Smith,50]\n[Eve,Jackson,94]\n[Maurice,Dupont,40]\n[Loris,Morez,20]\n[Edith,Euriez,34]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D1.toString(), D1.toString().equals(expResult));
        
    }
    
    //----------------------------------------------------
    @Test
    public void creationTest_isWellCreatedfromGoodData() {
        
        //CREATION : dataframe à partir d'ArrayList
        ArrayList<String> labels =new ArrayList<String>();
        labels.add("Firstname");
        labels.add("Lastname");
        labels.add("Age");
        
        ArrayList<Object> line1 = new ArrayList<Object>();
        line1.add("Jill");
        line1.add("Smith");
        line1.add(50);
        
        ArrayList<Object> line2 = new ArrayList<Object>();
        line2.add("Eve");
        line2.add("Jackson");
        line2.add(94);

        ArrayList<Object> line3 = new ArrayList<Object>();
        line3.add("Maurice");
        line3.add("Dupont");
        line3.add(40);
        
        ArrayList<ArrayList<Object>> data =new ArrayList<ArrayList<Object>>();
        data.add(line1);
        data.add(line2);
        data.add(line3);
        
        //CREATION : dataframe à partir de Data
       DataFrame D = new DataFrame(labels, data);
        
        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Jill,Smith,50]\n[Eve,Jackson,94]\n[Maurice,Dupont,40]\n";
        assertTrue("RESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+D.toString(), D.toString().equals(expResult));
    }
    //----------------------------------------------------------------
    @Test
    public void creationTest_DataframeisNull() {
        DataFrame D = new DataFrame();
        String expResult = "\n[]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+D.toString(), D.toString().equals(expResult));
    }
    //----------------------------------------------------------------
    @Test
    public void creationTest_DataframeisFileEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(1);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D1.toString(), D1.toString().equals(expResult));
        
    }
    //----------------------------------------------------------------
    //-----------------------SELECT-DATAFRAME-------------------------
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        DataFrame D2 = D1.getRow(0); //TODO spécifier dans la javadoc 

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Jill,Smith,50]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowisTooBig() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : index donné invalide.");   
        
        //TEST : Création de dataframe à partir du head(2) de D1
        D1.getRow(10);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowWhenDataframeIsEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(1);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : index donné invalide.");   
        
        //TEST : Création de dataframe à partir du head(2) de D1
        D1.getRow(0);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowsisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        int[] d = {0,1};
        DataFrame D2 = D1.getRows(d); //TODO spécifier dans la javadoc 

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Jill,Smith,50]\n[Eve,Jackson,94]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowsWithIndexesEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : Le tableau d'index ne doit pas être vide.");   
        
        //TEST : Création de dataframe à partir du head(2) de D1
        int[] d = {};
        D1.getRows(d);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowsWhenDataframeIsEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(1);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : indexes données invalides.");   
        
        //TEST : Création de dataframe à partir du head(2) de D1
        int[] d = {0};
        D1.getRows(d);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowsBetweenisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        DataFrame D2 = D1.getRowsBetween(1,4); //TODO spécifier dans la javadoc 

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Eve,Jackson,94]\n[Maurice,Dupont,40]\n[Loris,Morez,20]\n[Edith,Euriez,34]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getRowsBeteenWhenIndexesInverted() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : indexes x1 et/ou xn invalides.");   
        
        //TEST : Création de dataframe à partir du head(2) de D1
        D1.getRowsBetween(3,0);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        DataFrame D2 = D1.getColumn("Firstname"); //TODO spécifier dans la javadoc 

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname]\n[Jill]\n[Eve]\n[Maurice]\n[Loris]\n[Edith]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnWhenLabelDontExist() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : label donné invalide ou non existant.");   
        
        //TEST : 
        D1.getColumn("Salary");
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnWhenDataframeIsEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(1);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : label donné invalide ou non existant.");   
        
        //TEST : 
        D1.getColumn("Firstname");
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnsisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : test de fonction
        ArrayList<String> listLabel = new ArrayList<String>();
        listLabel.add("Firstname");
        listLabel.add("Age");
        DataFrame D2 = D1.getColumns(listLabel); //TODO spécifier dans la javadoc 

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Age]\n[Jill,50]\n[Eve,94]\n[Maurice,40]\n[Loris,20]\n[Edith,34]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));       
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnsWhenListIsEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : liste de labels donné vide.");   
        
        //TEST : 
        ArrayList<String> listLabel = new ArrayList<String>();
        DataFrame D2 = D1.getColumns(listLabel);
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getColumnsWhenListGivenIsEmpty() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(1);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : label donné invalide ou non existant.");   
        
        //TEST : 
        D1.getColumn("Firstname");
    }
    //----------------------------------------------------------------
    @Test
    public void selectTest_getElementisOkay() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : test de fonction
        //String D2 = D1.getElement(3, "Lastname"); //TODO spécifier dans la javadoc 
        String D2 = "pas fini";
        
        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "Morez";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));       
    }
    //-------------------------------------------------------------
    //--------------------INFORMATION-DATAFRAME--------------------
    //-------------------------------------------------------------
    @Test
    public void infoTest_headIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        DataFrame D2 = D1.head(2);

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Jill,Smith,50]\n[Eve,Jackson,94]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //-------------------------------------------------------------
    @Test
    public void infoTest_headIncorrect_IndexTooBig() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : Level donné dans head() est plus grand que la taille du dataframe.");
        
        //TEST : Création de dataframe à partir du head(2) de D1
        D1.head(10);

    }
    //-------------------------------------------------------------
    @Test
    public void infoTest_tailIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //TEST : Création de dataframe à partir du head(2) de D1
        DataFrame D2 = D1.tail(2);

        //TEST : Comparer le D.toString() avec la sortie attendue
        String expResult = "\n[Firstname,Lastname,Age]\n[Loris,Morez,20]\n[Edith,Euriez,34]\n";
        assertTrue("\nRESULTAT ATTENDU :" + expResult + "\nRESULTAT OBTENU :"+ D2.toString(), D2.toString().equals(expResult));
        
    }
    //-------------------------------------------------------------
    @Test
    public void infoTest_tailIncorrect_IndexTooBig() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);
        
        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : Level donné dans tail() est plus grand que la taille du dataframe.");
        
        //TEST : Création de dataframe à partir du head(2) de D1
        D1.tail(10);

    }
    //-------------------------------------------------------------
    //--------------------STATISTIQUE-DATAFRAME--------------------
    //-------------------------------------------------------------
    @Test
    public void statTest_medianedIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer résultat attendu et résultat obtenu
        float expResult = 47.6F;
        assertTrue("\nRESULTAT ATTENDU :\n" + expResult + "\nRESULTAT OBTENU :\n"+ D1.median("Age"), D1.median("Age") == expResult); 
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_medianeInIncorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : La colonne n'est pas de type int ou float.");

        //TEST
        D1.median("Firstname");
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_SumdIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer résultat attendu et résultat obtenu
        float expResult = 238.F;
        assertTrue("\nRESULTAT ATTENDU :\n" + expResult + "\nRESULTAT OBTENU :\n"+ D1.sum("Age"), D1.sum("Age") == expResult); 
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_SumInIncorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : La colonne n'est pas de type int ou float.");

        //TEST
        D1.sum("Firstname");
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_MinIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer résultat attendu et résultat obtenu
        float expResult = 20.F;
        assertTrue("\nRESULTAT ATTENDU :\n" + expResult + "\nRESULTAT OBTENU :\n"+ D1.min("Age"), D1.min("Age") == expResult); 
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_MinInIncorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : La colonne n'est pas de type int ou float.");

        //TEST
        D1.min("Firstname");
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_MaxIsCorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //TEST : Comparer résultat attendu et résultat obtenu
        float expResult = 94.F;
        assertTrue("\nRESULTAT ATTENDU :\n" + expResult + "\nRESULTAT OBTENU :\n"+ D1.max("Age"), D1.max("Age") == expResult); 
    }
    //-------------------------------------------------------------
    @Test
    public void statTest_MaxInIncorrect() throws Exception {
        //CREATION : fichier test
        final File tempFile = listTestFile.get(0);
        
        //CREATION : dataframe à partir du fichier
        String nameFile = tempFile.toPath().toString(); //Donne le chemin complet du fichier
        DataFrame D1 = new DataFrame(nameFile);

        //CREATION EXCEPTION
        ex.expect(Exception.class);
        ex.expectMessage("ERREUR : La colonne n'est pas de type int ou float.");

        //TEST
        D1.max("Firstname");
    }
    
}