package dataframe;

import java.util.ArrayList;

/**
 * Ligne
 */
public class Ligne {

    private ArrayList<Element> line;

    public Ligne() {
    	line = new ArrayList<Element>();
        //TODO créer une ligne
    }

    /**
     * @return the line
     */
    public ArrayList<Element> getLine() {
        return line;
    }

    /**
     * @param line the line to set
     */
    public void setLine(ArrayList<Element> line) {
        this.line = line;
    }


    public Element getline(int i) {
    	return this.getLine().get(i);
    }
    public void addElem(Element e) {
        line.add(e);
    }
    public void addElem(Object e) {
        line.add(new Element(e));
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((line == null) ? 0 : line.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ligne other = (Ligne) obj;
		if (line == null) {
			if (other.getLine() != null)
				return false;
		} else {
			if(line.size()!=other.getLine().size())
				return false;
			for(int i=0;i<line.size();i++) {
				if(line.get(i)!= other.getLine().get(i))
					return false;
			}
		}
		return true;
	}
    


    //TODO éventuellement compléter avec d'autres méthodes
}