package dataframe;

import java.util.ArrayList;
import com.opencsv.CSVReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * Classe de gestion de dataframes.
 * @version 1.0
 * @author Marianne Garnier Benmoussa Nadia
 */
public class DataFrame {
            
	private ArrayList<Label> labels;
	private ArrayList<Ligne> data;
	
    //----------------------------------------------------------------
    //------------------------CONSTRUCTORS----------------------------
    //----------------------------------------------------------------
	/**
	* Création d'un dataframe à partir d'un fichier CSV. Le séparateur utilisé du fichier doit être une virgule. <p>
	* Exemple : <p>
	* X,Y <p>
	* a,1 <p>
	* b,2 <p>
	* Le Dataframe généré s'assure que les éléments d'une même colonne soit du même type.
	* @param labels   nom du fichier .csv
	* @throws Exception 
	*/
	public DataFrame(String nameCSV) throws Exception {
            Reader reader;
            CSVReader csvReader;
            try {
                //LECTURE du fichier
                reader = Files.newBufferedReader(Paths.get(nameCSV));
                csvReader = new CSVReader(reader);
                List<String[]> allRows = csvReader.readAll(); //Fournit une liste de lignes. CHaque ligne est un tableau de String.     
                if(allRows.isEmpty()) {
                	labels = new ArrayList<Label>();
    		        data = new ArrayList<Ligne>();
                }
                else{
                	//CREATION des labels
                    ArrayList<Label> allLabels = new ArrayList<Label>();
                    for (String elem : allRows.get(0)) {
                        Label l = new Label(elem);
                        allLabels.add(l);
                    }
                    //CREATION des lignes
                    ArrayList<Ligne> allData = new ArrayList<Ligne>();
                    for (int i = 1; i< allRows.size(); i++) {
                        Ligne line = new Ligne();
                        for (int j = 0 ; j<allRows.get(i).length; j++ ) {
                            Element e = new Element(allRows.get(i)[j]);
                            line.addElem(e);
                        }
                        allData.add(line);
                        //TODO vérifier que allData[0] n'est pas les labels
                    }
                    //CREATION du Dataframe
                    this.labels = allLabels;
                    this.data = allData;
                }
            } catch (IOException ex) {
                System.err.println("ERREUR : Fichier invalide.");
            }

	}
		//----------------------------------------------------------------
		/**
		 * Création d'un dataframe vide.
		 */
        public DataFrame() {
            labels = new ArrayList<Label>();
            data = new ArrayList<Ligne>();
        }

        //----------------------------------------------------------------
		/**
		 * Création d'un dataframe à partir de données existantes. 
		 * @param labels ArrayList de Label (=string)
		 * @param data ArrayList de lignes, chaque ligne étant une Arraylist d'Object
		 */
        public DataFrame(ArrayList<String> labels,ArrayList<ArrayList<Object>> data) {
        	ArrayList<Label> lab = stringsToLabels(labels);
            ArrayList<Ligne> dataframe =new ArrayList<Ligne>(); 
            for(int i= 0; i< labels.size(); i++) {
                Ligne line = new Ligne();
            	for(int j=0; j<data.size(); j++) {
                    line.addElem(new Element(data.get(i).get(j)));   
            	}
                dataframe.add(line);
            }
        	this.labels = lab; 
            this.data = dataframe;
		}
		
      	//----------------------------------------------------------------
        //----------------------------------------------------------------
		//----------------------------------------------------------------
		/**
		 * Convertie une arrayList de String en arrayList de labels. Cette méthode permet entre autre de générer un dataframe à partir d'un fichier ou d'une liste fournit par l'utilisateur.
		 * @param strings  ArrayList de noms de labels (=string)
		 */
        private ArrayList<Label> stringsToLabels(ArrayList<String> strings) {
        	ArrayList<Label> labels = new ArrayList<Label>();
        	for(String s : strings) {
        		labels.add(new Label(s));
        	}
        	return labels;
        }
	
		//----------------------------------------------------------------
		/**
		 * Convertie une arrayList de Label  en arrayList de String. 
		 * @param strings  ArrayList de noms de labels (=string)
		 */
        private ArrayList<String> labelsToStrings(ArrayList<Label> labels) {
        	ArrayList<String> strings = new ArrayList<String>();
        	for(Label l : labels) {
        		strings.add(l.getL());
        	}
        	return strings;
        }
	
        //----------------------------------------------------------------
		/**
		 * Création d'un dataframe à partir de données existantes. 
		 * @param labels ArrayList de Label (=string)
		 * @param data ArrayList de lignes, chaque ligne étant une Arraylist d'Element (=Object)
		 */
        private DataFrame DataFrameFromLabel(ArrayList<Label> labels, ArrayList<Ligne> data) {
    
			DataFrame D =  new DataFrame();
			
			//Création des labels (Clonage de labels)
			ArrayList<Label> allLabels = new ArrayList<Label>();
			for(int j=0 ; j< labels.size(); j++) {
				Label l = new Label(labels.get(j).getL());
			    allLabels.add(l);
			}

			//Création des datas (Clonage de this.data)
			ArrayList<Ligne> allData = new ArrayList<Ligne>();
			for(int i= 0; i< data.size(); i++) {
	            Ligne newLine = new Ligne();
				for(int j=0 ; j< labels.size(); j++) {
					Element e = data.get(i).getline(j);
				    newLine.addElem(e);
				}
				allData.add(newLine);
			}  
			
			//Assemblement du dataframe
			D.data = allData;
			D.labels = allLabels;
			return D;
        }
        
	//----------------------------------------------------------------
    //------------------------GETTER/SETTER---------------------------
	//----------------------------------------------------------------
	/**
	* Permet de récupérer la liste des labels
	* @return Une ArrayList de Labels
	*/
	private ArrayList<Label> getLabels() {
		return labels;
	}
	//----------------------------------------------------------------
	/**
	* Permet d'affecter une arraylist de labels au dataframe.
	* @param labels ArrayList de Labels
	*/

	public void setLabels(ArrayList<String> labels) {
		this.labels = stringsToLabels(labels);

	}
	//----------------------------------------------------------------
	/**
	* Permet de récupérer les données (une liste de lignes, contenant chacune les éléments)
	* @return Une ArrayList de lignes, elles-même étant une arraylist contenant les éléments.
	*/
	private ArrayList<Ligne> getData() {
		return data;
	}
	//----------------------------------------------------------------
	/**
	* Permet de récupérer les données (une liste de lignes, contenant chacune les éléments)
	* @param data Arraylist de lignes, contenant les éléments.
	*/
	private void setData(ArrayList<Ligne> data) {
		this.data = data;
	}
	//----------------------------------------------------------------
	/**
	* Utilisée à l'intérieur de la classe 
	* Permet de récupérer les données d'une colonne, dont on spécifiera par son label.
	* @param label Le label de la colonne à récupérer
	* @return Une ArrayList d'éléments correspondants au label spécifié.
	*/
	private ArrayList<Element> getColonne(Label label) {
		// on trouve l'index id du label dans la liste des labels
		int id=0;
		Label l= labels.get(id);
		
		while(!l.equals(label)) {
			id++;
			l= labels.get(id);
		}	
		
		
		// on parcours les lignes pour récupérer leur id élem
		ArrayList<Element> colonne = new ArrayList<Element>();
		for(Ligne line: data) {
			ArrayList<Element> elems= line.getLine();
			colonne.add(elems.get(id));
		}
		return colonne;
	}
	//----------------------------------------------------------------
	/**
	* Permet de récupérer les données d'une ligne, spécifiée par son index. La première ligne est d'index 0, la deuxième d'index 1...
	* @param index l'index de la ligne à récupérer
	* @return La ligne d'index donné.
	*/
	private Ligne getLigne(int index) {
		return data.get(index);
	}
	//----------------------------------------------------------------
	/**
	* Permet de récupérer un élément se trouvant à la ligne "index", et à la colonne "label"
	* @param index l'index de la ligne où se trouve l'élément à récupérer
	* @param l le label de la colonne où se trouve l'élément à récupérer
	* @throws ex //TODO A COMPLETER : vérifier si index et s sont valides
	* @return L'élément se trouvant à la ligne "index", et à la colonne "label".
	*/
	private Element getElement(int index, Label l) {
		ArrayList<Element> col = getColonne(l);
		return col.get(index);
	}

	//----------------------------------------------------------------
	/**
	* Permet de savoir si un label est dans la liste des labels du dataframe
	* @param label nom du label à rechercher
	* @return Vrai si label est dans la liste, FAUX sinon.
	*/
	private boolean labelInDataFrame(String label) {
		for(Label l : this.labels) {
			if(l.getL().equals(label)) {
				return true;
			}
		}
		return false;
	}
	//----------------------------------------------------------------
    //-------------------------METHODS--------------------------------
	//----------------------------------------------------------------
	
	/**
	* Permet de récupérer les données d'une colonne, dont on spécifiera par son label.
	* @param label Le label de la colonne à récupérer
	* @return Une ArrayList d'éléments correspondants au label spécifié.
	*/
	/*public ArrayList<Object> getColonne(String label) {
		// on trouve l'index id du label dans la liste des labels
		int id=0;
		Label l= labels.get(id);
		
		while(!l.getL().equals(label)) {
			id++;
			l= labels.get(id);
		}		
		// on parcours les lignes pour récupérer leur id élem
		ArrayList<Object> colonne = new ArrayList<Object>();
		for(Ligne line: data) {
			ArrayList<Element> elems= line.getLine();
			colonne.add(elems.get(id).getE());
		}
		return colonne;
	}*/

	
	//----------------------------------------------------------------
	/**
	* Permet de récupérer un élément se trouvant à la ligne "index", et à la colonne "label". Très similaire à {@link #getElem(int, Label)}
	* @param index l'index de la ligne où se trouve l'élément à récupérer
	* @param l le label (sous forme de string) de la colonne où se trouve l'élément à récupérer
	* @throws ex //TODO A COMPLETER : vérifier si index et s sont valides
	* @return L'élément se trouvant à la ligne "index", et à la colonne "label".
	*/
	public Element getElement(int index, String s) {
		for(Label l : labels) {
			if(l.getL().equals(s))
				return getElement(index,l);
		}
		return null;
	}
    //----------------------------------------------------------------
	/**
	* Permet de récupérer la version "string" du dataframe. <p>
	* Exemple : pour le dataframe suivant : <p>
	* X,Y <p>
	* a,1 <p>
	* b,2 <p>
	* Le string retourné sera : <p>
	* [X,Y] <p>
	* [a,1] <p>
	* [b,2] <p>
	* @return Le dataframe sous forme de string. 
	*/
	@Override
	public String toString(){ //TODO Que fait toString si le dataframe est vide ?
	 	String data ="\n[";
	 	for(int i=0 ; i< this.labels.size(); i++) {
	 		if(i<this.labels.size()-1) {
		 		data = data +  this.labels.get(i).getL()+",";
	 		}else {
		 		data = data +  this.labels.get(i).getL()+"";

	 		}
	 	}
	 	data = data +"]\n";
	 	
	 	
	 	for(int i=0 ; i< this.data.size(); i++) {
	 		data= data+"[";
	 		for(int j=0 ; j< this.labels.size(); j++) {
		 		if(j<this.labels.size()-1) {
	 				data = data  + this.data.get(i).getline(j).getE().toString()+",";
		 		}else {
	 				data = data  + this.data.get(i).getline(j).getE().toString();

		 		}
	 		}	
	 		data = data +"]\n";
	 	}
			return data;
	 }	
	//----------------------------------------------------------------
	/**
	* Permet de récupérer une ligne, spécifiées par son index, et retourne un dataframe contenant QUE cette ligne.
	* @param index index de la ligne à récupérer
	* @throws Exception Si l'index donné est invalide
	* @return Le dataframe contenant la ligne spécifiée
	*/
	public DataFrame getRow(int index) throws Exception{
		if(index>= data.size() || index<0){
			throw new Exception("ERREUR : index donné invalide.");
		}
		
		ArrayList<Ligne> newData = new ArrayList<Ligne>();
		newData.add(data.get(index));

		//CREATION Dataframe associé
		return DataFrameFromLabel(this.labels,newData);
	}
	//----------------------------------------------------------------
	/**
	* Permet de récupérer plusieurs lignes, spécifiées par un tableau d'index, et retourne un dataframe contenant QUE ces lignes.
	* @param indexes tableau d'index des lignes à récupérer
	* @throws Exception Si le tableau d'indexes est vide ou que les indexes données sont invalides.
	* @return Le dataframe contenant les lignes spécifiées 
	*/
	public DataFrame getRows(int[] indexes) throws Exception{
		if(indexes==null || indexes.length==0) {
			throw new Exception("ERREUR : Le tableau d'index ne doit pas être vide.");
		}
		//on teste si les index sont valides
		for(int index:indexes) {
			if(index>= data.size() || index<0)
				throw new Exception("ERREUR : indexes données invalides.");
		}
		ArrayList<Ligne> lines = new ArrayList<Ligne>();
		
		for(int ind: indexes) {
			lines.add(data.get(ind));
		}
		return DataFrameFromLabel(labels,lines);
	}
	
	//----------------------------------------------------------------
	/**
	* Permet de récupérer les lignes entre les indices x1 et xn, et retourne un dataframe contenant QUE ces lignes.
	* @param x1 index de la première ligne à récupérer
	* @param xn index de la dernière ligne à récupérer
	* @throws Exception Si les indexes donnés sont invalides
	* @return Le dataframe contenant les lignes entre x1 et xn
	*/
	public DataFrame getRowsBetween(int x1, int xn) throws Exception{
		//on teste si les indexs sont valides
		if(x1 >= data.size() || xn>= data.size()|| x1<0 || xn<0 || x1>xn)
			throw new Exception("ERREUR : indexes x1 et/ou xn invalides.");
			
		ArrayList<Ligne> lines = new ArrayList<Ligne>();
		for(int i=x1;i<=xn;i++) {
			lines.add(data.get(i));
		}
		return DataFrameFromLabel(labels,lines);
	}
	
	//----------------------------------------------------------------
	/**
	* Retourne un dataframe à partir d'un label de colonne.
	* @param l label de la colonne à retourner.
	* @return Un dataframe ne contenant que la colonne de label l.
	*/	
	private DataFrame getColumn(Label l) throws Exception{
		if(l==null || !labelInDataFrame(l.getL())) {
			throw new Exception("getColumn(Label l): label invalide");			
		}
		ArrayList<Element> col = getColonne(l);
		ArrayList<Ligne> datas = new ArrayList<Ligne>();
		//on créé une ligne pour chaque élément de la colonne
		for(Element e: col) {
			Ligne line = new Ligne();
			line.addElem(e);
			datas.add(line);
		}
		ArrayList<Label> labels = new ArrayList<Label>();
		labels.add(l);
		return DataFrameFromLabel(labels, datas);
	}
	
	
	//----------------------------------------------------------------
	/**
	* Retourne un dataframe à partir d'un label de colonne.
	* @param label, la colonne à retourner.
	* @return Un dataframe ne contenant que la colonne de label l.
	*/	
	public DataFrame getColumn(String label) throws Exception{
		
		//Construction des labels
		Label l = new Label(label);

		if(!labelInDataFrame(l.getL())) {
			throw new Exception("ERREUR : label donné invalide ou non existant.");			
		}

		ArrayList<Label> labels = new ArrayList<Label>();
		labels.add(l);

		//Construction des datas
		ArrayList<Element> col = getColonne(l);
		ArrayList<Ligne> datas = new ArrayList<Ligne>();
		
		//on créé une ligne pour chaque élément de la colonne
		for(Element e: col) {
			Ligne line = new Ligne();
			line.addElem(e);
			datas.add(line);
		}

		
		return DataFrameFromLabel(labels, datas);
	}
	//----------------------------------------------------------------
	/**
	* Retourne un dataframe à partir d'une arraylist de labels de colonne
	* @param lab ArrayList de labels des colonne à retourner.
	* @return Un dataframe ne contenant QUE les colonnes spécifiées dans labels.
	*/		
	public DataFrame getColumns(ArrayList<String> lab) throws Exception{
		ArrayList<Label> labels = stringsToLabels(lab);
		//on teste si les labels existent
		if(labels==null || labels.isEmpty()) {
			throw new Exception("ERREUR : liste de labels donné vide.");
		}
		for(Label l:labels) {	
			if(!labelInDataFrame(l.getL())) {
				throw new Exception("ERREUR : label donné invalide ou non existant.");			
			}
		}
		//on récupère les colonnes sélectionnées
		ArrayList<ArrayList<Element>> listCol = new ArrayList<ArrayList<Element>>();
		for(Label l:labels) {
			listCol.add(getColonne(l));
		}
		//on crée la liste de lignes
		ArrayList<Ligne> datas = new ArrayList<Ligne>();
		int nbLine= listCol.get(0).size();
		for(int i=0;i<nbLine;i++) {
			datas.add(new Ligne());
		}
		//on ajoute les éléments des colonnes dans les lignes
		for(ArrayList<Element> col:listCol) {
			for(int i=0;i<nbLine;i++) {
				datas.get(i).addElem(col.get(i));
			}
		}
		return DataFrameFromLabel(labels, datas);
	}
	
	//----------------------------------------------------------------
	//------------------------INFORMATIONS----------------------------
	//----------------------------------------------------------------	
	/**
	* Permet de récupérer les "level" premières lignes.
	* @param level nombre de lignes à récupérer en tête du dataframe
	* @throws Exception Si level est plus grand que la taille du Dataframe
	* @return Le dataframe contenant les "level" premières lignes 
	*/
	public DataFrame head(int level) throws Exception {
		if(level >this.data.size() ) {
			throw new Exception("ERREUR : Level donné dans head() est plus grand que la taille du dataframe.");
		}else {
			DataFrame data =  new DataFrame();
			ArrayList<Label> allLabels = new ArrayList<Label>();
			for(int j=0 ; j< this.labels.size(); j++) {
				Label l = new Label(this.labels.get(j).getL());
			    allLabels.add(l);
			}
			ArrayList<Ligne> allData = new ArrayList<Ligne>();
			for(int i=0 ; i<level ; i++) {
	            Ligne line = new Ligne();
				for(int j=0 ; j< this.labels.size(); j++) {
					Element e = new Element(this.data.get(i).getline(j).getE());
				    line.addElem(e);
				}
				allData.add(line);
			}				    
				data.data = allData;
				data.labels =allLabels;
				return data;			
		}	        	
	}
	//----------------------------------------------------------------	
	/**
	* Permet de récupérer les "level" dernières lignes.
	* @param level nombre de lignes à récupérer en queue du dataframe
	* @throws Exception Si level est plus grand que la taille du Dataframe
	* @return Le dataframe contenant les "level" dernières lignes 
	*/
	public DataFrame tail(int level) throws Exception {
		if(level >this.data.size() ) {
			throw new Exception("ERREUR : Level donné dans tail() est plus grand que la taille du dataframe.");

		}else {
			DataFrame data =  new DataFrame();
			ArrayList<Label> allLabels = new ArrayList<Label>();
			for(int j=0 ; j< this.labels.size(); j++) {
				Label l = new Label(this.labels.get(j).getL());
			    allLabels.add(l);
			}
			ArrayList<Ligne> allData = new ArrayList<Ligne>();
			for(int i=this.data.size()-level ; i<this.data.size() ; i++) {
	            Ligne line = new Ligne();
				for(int j=0 ; j< this.labels.size(); j++) {
					Element e = new Element(this.data.get(i).getline(j).getE());
				    line.addElem(e);
				}
				allData.add(line);
			}    
				data.data = allData;
				data.labels =allLabels;
				return data;
		}		
		        	
	}
	//----------------------------------------------------------------
	//------------------------STATISTIQUES----------------------------
	//----------------------------------------------------------------
	/**
	 * Vérifie si l'élément est un entier
	 * @param elem élément sous forme de string
	 * @return Vrai si c'est un entier, faux sinon.
	 */
	private boolean estUnEntier(String elem){
		try {
			Integer.parseInt(elem);
		} catch (NumberFormatException e){
			return false;
		}
 
		return true;
	}
	//----------------------------------------------------------------
	/**
	 * Vérifie si l'élément est un float
	 * @param elem élément sous forme de string
	 * @return Vrai si c'est un float, faux sinon.
	 */
	private boolean estUnFloat(String elem){
		try {
			Float.parseFloat(elem);
		} catch (NumberFormatException e){
			return false;
		}
 
		return true;	
	}
	//----------------------------------------------------------------
	/**
	 * Retourne la moyenne de toutes les valeurs de la colonne donnée
	 * @param label nom de la colonne donnée 
	 * @return Retourne la moyenne de toutes les valeurs de la colonne donnée
	 * @throws Exception 
	 */
	public float median(String label ) throws Exception {
		float somme=0;
		try {
			for(int i=0; i<this.getLabels().size(); i++) {
				if(this.labels.get(i).getL().equals(label)) {
					for (int j = 0; j<this.getData().size(); j++) {
						if((estUnEntier(this.data.get(j).getline(i).getE().toString())) || (estUnFloat(this.data.get(j).getline(i).getE().toString()))) {
							somme = somme + Float.valueOf(this.data.get(j).getline(i).getE().toString());							
						}else {
							throw new Exception("ERREUR : La colonne n'est pas de type int ou float.");

						}
					}					
				}
			}	
		}
		catch(NullPointerException e) { 
            System.out.println("ERREUR : Pointeur null"); 
        }
		return somme/this.getData().size();	

	}
	//----------------------------------------------------------------	
	/**
	 * retourne la somme de toutes les valeurs de la colonne donnée.
	 * @param label le label de la colonne sélectionnée
	 * @return La somme des éléments de la colonne.
	 * @throws Exception 
	 */
	public float sum(String label ) throws Exception {
		float somme=0;
		try {
			for(int i=0; i<this.getLabels().size(); i++) {
				if(this.labels.get(i).getL().equals(label)) {
					for (int j = 0; j<this.getData().size(); j++) {
						if((estUnEntier(this.data.get(j).getline(i).getE().toString())) || (estUnFloat(this.data.get(j).getline(i).getE().toString()))) {
							somme = somme + Float.valueOf(this.data.get(j).getline(i).getE().toString());						
						}else {
							throw new Exception("ERREUR : La colonne n'est pas de type int ou float.");		
						}
					}	
				}
			}	
		}
		catch(NullPointerException e) { 
            System.out.println("Erreur"); 
        }
		return somme;

	}
	//----------------------------------------------------------------	
	/**
	 * retourne le minimum de toutes les valeurs de la colonne donnée.
	 * @param label le label de la colonne sélectionnée
	 * @return Le minimum des éléments de la colonne.
	 * @throws Exception 
	 */
	public float min(String label) throws Exception {
		float min = Float.MAX_VALUE;
		try {
			for(int i=0; i<this.getLabels().size(); i++) {
				if(this.labels.get(i).getL().equals(label)) {
					for (int j = 0; j<this.getData().size(); j++) {
						if((estUnEntier(this.data.get(j).getline(i).getE().toString())) || (estUnFloat(this.data.get(j).getline(i).getE().toString()))) {
							if(min > Float.valueOf(this.data.get(j).getline(i).getE().toString())) {
								min = Float.valueOf(this.data.get(j).getline(i).getE().toString());
							}
						}else {
							throw new Exception("ERREUR : La colonne n'est pas de type int ou float.");

						}
					}
				}
			}
		}
		catch(NullPointerException e) { 
            System.out.println("Caught in main."); 
    		return 0;
        }
		return min;

	}
	//----------------------------------------------------------------	
	/**
	 * retourne le maximum de toutes les valeurs de la colonne donnée.
	 * @param label le label de la colonne sélectionnée
	 * @return Le maximum des éléments de la colonne.
	 * @throws Exception 
	 */
	public float max(String label) throws Exception {
		float max = Float.MIN_VALUE;
		try {
			for(int i=0; i<this.getLabels().size(); i++) {
				if(this.labels.get(i).getL().equals(label)) {
					for (int j = 0; j<this.getData().size(); j++) {
						if((estUnEntier(this.data.get(j).getline(i).getE().toString())) || (estUnFloat(this.data.get(j).getline(i).getE().toString()))) {
							if(max < Float.valueOf(this.data.get(j).getline(i).getE().toString())) {
								max = Float.valueOf(this.data.get(j).getline(i).getE().toString());
							}
						}else {
							throw new Exception("ERREUR : La colonne n'est pas de type int ou float.");

						}
					}					
				}
			}			
		}
		catch(NullPointerException e) { 
            System.out.println("Caught in main."); 
        }	
		return max;

	}
	
	//----------------------------------------------------------------
	//------------------------MANIPULATIONS---------------------------
	//----------------------------------------------------------------
	/**
	 * Ajouter des lignes au Dataframe D à partir d'une liste de lignes
	 * @param data  la liste de ligne à rajouter 
	 * @throws Exception 
	 */	
	public void addRows(ArrayList<Ligne> data) throws Exception{
		//on vérifie le type
		if(data!=null) {
			ArrayList<Element> line1 = this.data.get(0).getLine();
			for(Ligne l:data) {
				for (int i = 0; i < line1.size(); i++) {
					if(l.getLine().get(i).getClass()!=line1.get(i).getClass()) {
						throw new Exception("Erreur addRows(Arraylist<Ligne> : le type de l'élément \" "+ l.getLine().get(i)+" \" ne correspond pas à la colonne \""+labels.get(i)+"\".");
					}
				}
			}
			//on ajoute les lignes
			for(Ligne li: data) {
				this.data.add(li);
			}
		}
		
	}
	//----------------------------------------------------------------
	/**
	 *  Ajouter des colonnes  au Dataframe D à partir d'une liste de lignes
	 * @param labels
	 */
	public void addColumns(ArrayList<String> labels) {
		ArrayList<Label> lab = stringsToLabels(labels);
		for(Label l : lab){
			this.labels.add(l);
			for(Ligne line: this.data) {
				line.addElem(null);
			}
		}
		
	}
	//----------------------------------------------------------------
	/**
	 * Change l'élément e trouvant à la ligne x, label L par la valeur C
	 * @param c le nouvel objet
	 * @param x l'index de la ligne
	 * @param l le label de la colonne
	 * @throws Exception 
	 */	
	public void setElement(Object c, int x, String l) throws Exception{
		if(!labelInDataFrame(l)) {
			throw new Exception("Erreur SetElement(Object,int,String), "+l+" n'est pas une colonne");
		}else if(x>=data.get(0).getLine().size()){
			throw new Exception("Erreur SetElement(Object,int,String), "+x+" n'est pas un index");
		}else if(c.getClass()!=data.get(0).getline(x).getClass()) {
			throw new Exception("Erreur SetElement(Object,int,String), l'objet"+c+" n'est pas du type de la colonne "+l);
		}else {
			getLigne(x).getLine().set(x, new Element(c));
		}
	}
	//----------------------------------------------------------------
	/**
	 * Compare les labels avec une autre liste de labels
	 * @param lab2 une liste de labels
	 * @return true si les labels du dataframe sont les mêmes que ceux contenu dans lab2, false sinon
	 * @author Marianne
	 * */
	private boolean labelsEquals(ArrayList<Label> lab2) {
		if(labels==lab2)
			return true;
		if(labels == null) {
			if(lab2!=null)
				return false;
		}else {
			if(lab2==null)
				return false;
		}
		for(int i=0;i<lab2.size();i++) {
			if(!this.labels.get(i).equals(lab2.get(i))) {
				return false;
			}
		}
		return true;
	}
	//----------------------------------------------------------------
	/**
	 * Retourne l'union (sur les lignes !) de deux DataFrames D1 et D2. D1 et D2 DOIVENT avoir les MEMES labels.
	 * @param d2 un dataframe
	 * @return un dataframe de l'union des deux dataframes.
	 * @throws Exception 
	 * */	
	public DataFrame union(DataFrame d2) throws Exception{
		ArrayList<Label> lab2=d2.getLabels();
		if(!labelsEquals(lab2)) {
			throw new Exception("Erreur union : les deux DataFrame ne contiennent pas les memes labels");
		}
		DataFrame d3 = DataFrameFromLabel(this.labels, this.data);
		ArrayList<Ligne> data2 = d2.getData();
		for(Ligne line : data2) {
			d3.getData().add(line);
		}
		return d3;
	}
	//----------------------------------------------------------------
	/**
	 * Retourne l'intersection (sur les lignes !) de deux DataFrames D1 et D2. D1 et D2 DOIVENT avoir les MEMES labels
	 * @param d2 un dataframe
	 * @return un dataframe de l'intersection des deux dataframes.
	 * @throws Exception 
	 * */	
	public DataFrame intersection(DataFrame d2) throws Exception {
		ArrayList<Label> lab2=d2.getLabels();
		if(!labelsEquals(lab2)) {
			throw new Exception("Erreur intersection : les deux DataFrame ne contiennent pas les memes labels");
		}
		
		ArrayList<Ligne> data3=new ArrayList<Ligne>();
		ArrayList<Ligne> data2 = d2.getData();
		for(Ligne l1: data) {
			for(Ligne l2:data2) {
				if(l1.equals(l2)) {
					data3.add(l1);
				}
			}
		}
		
		return DataFrameFromLabel(labels, data3);
			
	}
	//----------------------------------------------------------------
	/**
	 * Compare le dataframe avec un autre dataframe
	 * @param d2 un dataframe
	 * @return true si les deux dataframes sont égaux, false sinon
	 * */	
	public boolean equals(DataFrame d2) {
		if (this == d2)
			return true;
		if (d2 == null)
			return false;
		//on teste l'égalité des labels
		ArrayList<Label> lab2=d2.getLabels();
		if(!labelsEquals(lab2)) {
			return false;
		}
		//on teste l'égalité des lignes
		if (data == null) {
			if (d2.data != null)
				return false;
		}else {
			if(d2.data==null)
				return false;
			for(Ligne line:data) {
				for(Ligne line2: d2.getData()) {
					if(!line.equals(line2))
						return false;
				}
					
			}
		}
		return true;
	}
	//----------------------------------------------------------------
	
	
		

}
