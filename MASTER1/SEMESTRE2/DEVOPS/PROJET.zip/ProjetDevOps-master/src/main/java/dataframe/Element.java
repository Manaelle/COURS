package dataframe;


/**
 * Label
 */
public class Element {

    private Object e;

    public Element(Object nameElem) {
         
        e = nameElem;
    }

    /**
     * @return the e
     */
    public Object getE() {
        return e;
    }

    /**
     * @param e the l to set
     */
    public void setE(Object e) {
        this.e = e;
    }


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Element other = (Element) obj;
		if (e == null) {
			if (other.e != null)
				return false;
		} else if (!e.equals(other.e))
			return false;
		return true;
	}
    
   
}