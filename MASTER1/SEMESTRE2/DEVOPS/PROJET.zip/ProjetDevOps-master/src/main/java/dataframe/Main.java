/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataframe;

/**
 *
 * @author benaissm
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*System.out.println("EN TRAVAUX !");
        DataFrame d = new  DataFrame("/home/b/benmousn/M1/S2/DEVOPS/ProjetDevOps/src/main/java/dataframe/data.csv");
        System.out.println(" "+d.toString());
        DataFrame data = d.head(2);
        System.out.println(" "+data.toString());*/

        
    }
    
}